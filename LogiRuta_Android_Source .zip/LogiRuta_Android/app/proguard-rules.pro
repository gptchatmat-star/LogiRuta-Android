# LogiRuta no requiere reglas ProGuard especiales en esta versión.
