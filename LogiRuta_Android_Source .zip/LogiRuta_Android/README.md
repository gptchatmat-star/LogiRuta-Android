# LogiRuta Android

Versión Android de LogiRuta basada en la aplicación web existente.

## Funciones incluidas
- Centro de logística
- Registro y seguimiento de envíos
- Gestión de camiones
- Modo conductor
- Mapa OpenStreetMap con Leaflet
- Selección de puntos de recogida y entrega
- GPS del teléfono en modo conductor
- Datos guardados localmente en el dispositivo mediante WebView/localStorage

## Compilar APK
El repositorio incluye `.github/workflows/build-apk.yml`. Al subirlo a GitHub, ejecutar el workflow **Build LogiRuta APK** y descargar el artefacto `LogiRuta-Android-APK`.

## Instalación
El archivo generado será `app-debug.apk`. En Android, abrirlo y permitir "Instalar apps desconocidas" para el navegador o gestor de archivos si el sistema lo solicita.

## Nota
El mapa necesita conexión a Internet para descargar los mosaicos de OpenStreetMap y la biblioteca Leaflet tal como está configurada esta versión.
